(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/_7d0719._.js",
    "static/chunks/src_styles_Home_module_5aea15.css"
  ],
  "source": "dynamic"
});
