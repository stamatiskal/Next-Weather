(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push([
    "static/chunks/src_app_Search_page_tsx_36054f._.js",
    {},
]);
(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
  "path": "static/chunks/src_app_Search_page_tsx_36054f._.js",
  "chunks": [
    "static/chunks/_a6d9a7._.js",
    "static/chunks/src_styles_Search_module_33b1f1.css"
  ],
  "source": "dynamic"
});
