(globalThis.TURBOPACK = globalThis.TURBOPACK || []).push(["static/chunks/_a6d9a7._.js", {

"[project]/src/styles/Search.module.css [app-client] (css module)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
__turbopack_export_value__({
  "button": "Search-module__PdTcMW__button",
  "card": "Search-module__PdTcMW__card",
  "city": "Search-module__PdTcMW__city",
  "condition": "Search-module__PdTcMW__condition",
  "container": "Search-module__PdTcMW__container",
  "dateText": "Search-module__PdTcMW__dateText",
  "error": "Search-module__PdTcMW__error",
  "headerRow": "Search-module__PdTcMW__headerRow",
  "humidity": "Search-module__PdTcMW__humidity",
  "iconColumn": "Search-module__PdTcMW__iconColumn",
  "iconSmall": "Search-module__PdTcMW__iconSmall",
  "infoGrid": "Search-module__PdTcMW__infoGrid",
  "label": "Search-module__PdTcMW__label",
  "result": "Search-module__PdTcMW__result",
  "searchBar": "Search-module__PdTcMW__searchBar",
  "temp": "Search-module__PdTcMW__temp",
  "title": "Search-module__PdTcMW__title",
  "topSection": "Search-module__PdTcMW__topSection",
  "value": "Search-module__PdTcMW__value",
  "valueSmall": "Search-module__PdTcMW__valueSmall",
  "wind": "Search-module__PdTcMW__wind",
});
}}),
"[project]/src/app/Search/page.tsx [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, k: __turbopack_refresh__, m: module, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "default": (()=>Search)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__ = __turbopack_import__("[project]/src/styles/Search.module.css [app-client] (css module)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$seo$2f$lib$2f$next$2d$seo$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next-seo/lib/next-seo.module.js [app-client] (ecmascript)");
;
var _s = __turbopack_refresh__.signature();
"use client";
;
;
;
const API_KEY = "70db354af9884cbdbf3112201253103";
function Search() {
    _s();
    const [searchInput, setSearchInput] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])("");
    const [weatherData, setWeatherData] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["useState"])(false);
    const handleInputChange = (e)=>{
        const value = e.target.value;
        const filteredValue = value.replace(/[^a-zA-Z\s]/g, "");
        const formattedValue = filteredValue.split(" ").map((word)=>word.charAt(0).toUpperCase() + word.slice(1)).join(" ");
        setSearchInput(formattedValue);
    };
    const fetchWeather = async ()=>{
        if (!searchInput) return;
        setLoading(true);
        setError(null);
        try {
            const response = await fetch(`https://api.weatherapi.com/v1/current.json?key=${API_KEY}&q=${searchInput}`);
            if (!response.ok) {
                throw new Error("I couldn't find that location. Please try again.");
            }
            const data = await response.json();
            setWeatherData(data);
            setError("");
        } catch (err) {
            setWeatherData(null);
            setError(err.message);
        } finally{
            setLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
        className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].container,
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].topSection,
            children: [
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h1", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].title,
                    children: "Search for Weather"
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 55,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("input", {
                    type: "text",
                    placeholder: "Enter a city name...",
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].searchBar,
                    value: searchInput,
                    onChange: handleInputChange,
                    onKeyDown: (e)=>e.key === "Enter" && fetchWeather(),
                    "data-testid": "search-input"
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 56,
                    columnNumber: 9
                }, this),
                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("button", {
                    onClick: fetchWeather,
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].button,
                    "data-testid": "search-button",
                    children: "Get Weather"
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 65,
                    columnNumber: 9
                }, this),
                weatherData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2d$seo$2f$lib$2f$next$2d$seo$2e$module$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["NextSeo"], {
                    title: `Weather in ${weatherData.location.name} - Weather App`,
                    description: `Current weather in ${weatherData.location.name}, ${weatherData.location.country}.`,
                    canonical: `http://172.30.77.82:3001/search?city=${weatherData.location.name}`,
                    openGraph: {
                        title: `Weather in ${weatherData.location.name}`,
                        description: `Current temperature, condition, humidity, and wind in ${weatherData.location.name}, ${weatherData.location.country}.`,
                        url: `http://172.30.77.82:3001/search?city=${weatherData.location.name}`
                    }
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 74,
                    columnNumber: 11
                }, this),
                error && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].error,
                    "data-testid": "error-msg",
                    children: error
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 87,
                    columnNumber: 11
                }, this),
                weatherData && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].result,
                    children: [
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].headerRow,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("h2", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].city,
                                    children: [
                                        weatherData.location.name,
                                        ", ",
                                        weatherData.location.country
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 94,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconColumn,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("img", {
                                            src: weatherData.current.condition.icon,
                                            alt: "weather icon",
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].iconSmall
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 98,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].dateText,
                                            children: new Date(weatherData.location.localtime).toLocaleDateString()
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 103,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 97,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/Search/page.tsx",
                            lineNumber: 93,
                            columnNumber: 13
                        }, this),
                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].infoGrid,
                            children: [
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].temp}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                            children: "Temperature"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 113,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].value,
                                            children: [
                                                weatherData.current.temp_c,
                                                "°C"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 114,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 112,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].condition}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                            children: "Condition"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 120,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].value,
                                            children: weatherData.current.condition.text
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 121,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 119,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].humidity}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                            children: "Humidity"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 127,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].value,
                                            children: [
                                                weatherData.current.humidity,
                                                "%"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 128,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 126,
                                    columnNumber: 15
                                }, this),
                                /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("div", {
                                    className: `${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].card} ${__TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].wind}`,
                                    children: [
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].label,
                                            children: "Wind"
                                        }, void 0, false, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 134,
                                            columnNumber: 17
                                        }, this),
                                        /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("span", {
                                            className: __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$styles$2f$Search$2e$module$2e$css__$5b$app$2d$client$5d$__$28$css__module$29$__["default"].value,
                                            children: [
                                                weatherData.current.wind_kph,
                                                " kph"
                                            ]
                                        }, void 0, true, {
                                            fileName: "[project]/src/app/Search/page.tsx",
                                            lineNumber: 135,
                                            columnNumber: 17
                                        }, this)
                                    ]
                                }, void 0, true, {
                                    fileName: "[project]/src/app/Search/page.tsx",
                                    lineNumber: 133,
                                    columnNumber: 15
                                }, this)
                            ]
                        }, void 0, true, {
                            fileName: "[project]/src/app/Search/page.tsx",
                            lineNumber: 111,
                            columnNumber: 13
                        }, this)
                    ]
                }, void 0, true, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 92,
                    columnNumber: 11
                }, this),
                loading && /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["jsxDEV"])("p", {
                    "data-testid": "loading",
                    children: "Loading..."
                }, void 0, false, {
                    fileName: "[project]/src/app/Search/page.tsx",
                    lineNumber: 142,
                    columnNumber: 21
                }, this)
            ]
        }, void 0, true, {
            fileName: "[project]/src/app/Search/page.tsx",
            lineNumber: 54,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/src/app/Search/page.tsx",
        lineNumber: 53,
        columnNumber: 5
    }, this);
}
_s(Search, "ieYLoUzqGd1wlvkA6iKCWBrg4CA=");
_c = Search;
var _c;
__turbopack_refresh__.register(_c, "Search");
if (typeof globalThis.$RefreshHelpers$ === 'object' && globalThis.$RefreshHelpers !== null) {
    __turbopack_refresh__.registerExports(module, globalThis.$RefreshHelpers$);
}
}}),
"[project]/src/app/Search/page.tsx [app-rsc] (ecmascript, Next.js server component, client modules)": ((__turbopack_context__) => {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, t: __turbopack_require_real__ } = __turbopack_context__;
{
}}),
"[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
/**
 * @license React
 * react-jsx-dev-runtime.development.js
 *
 * Copyright (c) Meta Platforms, Inc. and affiliates.
 *
 * This source code is licensed under the MIT license found in the
 * LICENSE file in the root directory of this source tree.
 */ var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
"use strict";
"production" !== ("TURBOPACK compile-time value", "development") && function() {
    function getComponentNameFromType(type) {
        if (null == type) return null;
        if ("function" === typeof type) return type.$$typeof === REACT_CLIENT_REFERENCE$2 ? null : type.displayName || type.name || null;
        if ("string" === typeof type) return type;
        switch(type){
            case REACT_FRAGMENT_TYPE:
                return "Fragment";
            case REACT_PORTAL_TYPE:
                return "Portal";
            case REACT_PROFILER_TYPE:
                return "Profiler";
            case REACT_STRICT_MODE_TYPE:
                return "StrictMode";
            case REACT_SUSPENSE_TYPE:
                return "Suspense";
            case REACT_SUSPENSE_LIST_TYPE:
                return "SuspenseList";
        }
        if ("object" === typeof type) switch("number" === typeof type.tag && console.error("Received an unexpected object in getComponentNameFromType(). This is likely a bug in React. Please file an issue."), type.$$typeof){
            case REACT_CONTEXT_TYPE:
                return (type.displayName || "Context") + ".Provider";
            case REACT_CONSUMER_TYPE:
                return (type._context.displayName || "Context") + ".Consumer";
            case REACT_FORWARD_REF_TYPE:
                var innerType = type.render;
                type = type.displayName;
                type || (type = innerType.displayName || innerType.name || "", type = "" !== type ? "ForwardRef(" + type + ")" : "ForwardRef");
                return type;
            case REACT_MEMO_TYPE:
                return innerType = type.displayName || null, null !== innerType ? innerType : getComponentNameFromType(type.type) || "Memo";
            case REACT_LAZY_TYPE:
                innerType = type._payload;
                type = type._init;
                try {
                    return getComponentNameFromType(type(innerType));
                } catch (x) {}
        }
        return null;
    }
    function testStringCoercion(value) {
        return "" + value;
    }
    function checkKeyStringCoercion(value) {
        try {
            testStringCoercion(value);
            var JSCompiler_inline_result = !1;
        } catch (e) {
            JSCompiler_inline_result = !0;
        }
        if (JSCompiler_inline_result) {
            JSCompiler_inline_result = console;
            var JSCompiler_temp_const = JSCompiler_inline_result.error;
            var JSCompiler_inline_result$jscomp$0 = "function" === typeof Symbol && Symbol.toStringTag && value[Symbol.toStringTag] || value.constructor.name || "Object";
            JSCompiler_temp_const.call(JSCompiler_inline_result, "The provided key is an unsupported type %s. This value must be coerced to a string before using it here.", JSCompiler_inline_result$jscomp$0);
            return testStringCoercion(value);
        }
    }
    function disabledLog() {}
    function disableLogs() {
        if (0 === disabledDepth) {
            prevLog = console.log;
            prevInfo = console.info;
            prevWarn = console.warn;
            prevError = console.error;
            prevGroup = console.group;
            prevGroupCollapsed = console.groupCollapsed;
            prevGroupEnd = console.groupEnd;
            var props = {
                configurable: !0,
                enumerable: !0,
                value: disabledLog,
                writable: !0
            };
            Object.defineProperties(console, {
                info: props,
                log: props,
                warn: props,
                error: props,
                group: props,
                groupCollapsed: props,
                groupEnd: props
            });
        }
        disabledDepth++;
    }
    function reenableLogs() {
        disabledDepth--;
        if (0 === disabledDepth) {
            var props = {
                configurable: !0,
                enumerable: !0,
                writable: !0
            };
            Object.defineProperties(console, {
                log: assign({}, props, {
                    value: prevLog
                }),
                info: assign({}, props, {
                    value: prevInfo
                }),
                warn: assign({}, props, {
                    value: prevWarn
                }),
                error: assign({}, props, {
                    value: prevError
                }),
                group: assign({}, props, {
                    value: prevGroup
                }),
                groupCollapsed: assign({}, props, {
                    value: prevGroupCollapsed
                }),
                groupEnd: assign({}, props, {
                    value: prevGroupEnd
                })
            });
        }
        0 > disabledDepth && console.error("disabledDepth fell below zero. This is a bug in React. Please file an issue.");
    }
    function describeBuiltInComponentFrame(name) {
        if (void 0 === prefix) try {
            throw Error();
        } catch (x) {
            var match = x.stack.trim().match(/\n( *(at )?)/);
            prefix = match && match[1] || "";
            suffix = -1 < x.stack.indexOf("\n    at") ? " (<anonymous>)" : -1 < x.stack.indexOf("@") ? "@unknown:0:0" : "";
        }
        return "\n" + prefix + name + suffix;
    }
    function describeNativeComponentFrame(fn, construct) {
        if (!fn || reentry) return "";
        var frame = componentFrameCache.get(fn);
        if (void 0 !== frame) return frame;
        reentry = !0;
        frame = Error.prepareStackTrace;
        Error.prepareStackTrace = void 0;
        var previousDispatcher = null;
        previousDispatcher = ReactSharedInternals.H;
        ReactSharedInternals.H = null;
        disableLogs();
        try {
            var RunInRootFrame = {
                DetermineComponentFrameRoot: function() {
                    try {
                        if (construct) {
                            var Fake = function() {
                                throw Error();
                            };
                            Object.defineProperty(Fake.prototype, "props", {
                                set: function() {
                                    throw Error();
                                }
                            });
                            if ("object" === typeof Reflect && Reflect.construct) {
                                try {
                                    Reflect.construct(Fake, []);
                                } catch (x) {
                                    var control = x;
                                }
                                Reflect.construct(fn, [], Fake);
                            } else {
                                try {
                                    Fake.call();
                                } catch (x$0) {
                                    control = x$0;
                                }
                                fn.call(Fake.prototype);
                            }
                        } else {
                            try {
                                throw Error();
                            } catch (x$1) {
                                control = x$1;
                            }
                            (Fake = fn()) && "function" === typeof Fake.catch && Fake.catch(function() {});
                        }
                    } catch (sample) {
                        if (sample && control && "string" === typeof sample.stack) return [
                            sample.stack,
                            control.stack
                        ];
                    }
                    return [
                        null,
                        null
                    ];
                }
            };
            RunInRootFrame.DetermineComponentFrameRoot.displayName = "DetermineComponentFrameRoot";
            var namePropDescriptor = Object.getOwnPropertyDescriptor(RunInRootFrame.DetermineComponentFrameRoot, "name");
            namePropDescriptor && namePropDescriptor.configurable && Object.defineProperty(RunInRootFrame.DetermineComponentFrameRoot, "name", {
                value: "DetermineComponentFrameRoot"
            });
            var _RunInRootFrame$Deter = RunInRootFrame.DetermineComponentFrameRoot(), sampleStack = _RunInRootFrame$Deter[0], controlStack = _RunInRootFrame$Deter[1];
            if (sampleStack && controlStack) {
                var sampleLines = sampleStack.split("\n"), controlLines = controlStack.split("\n");
                for(_RunInRootFrame$Deter = namePropDescriptor = 0; namePropDescriptor < sampleLines.length && !sampleLines[namePropDescriptor].includes("DetermineComponentFrameRoot");)namePropDescriptor++;
                for(; _RunInRootFrame$Deter < controlLines.length && !controlLines[_RunInRootFrame$Deter].includes("DetermineComponentFrameRoot");)_RunInRootFrame$Deter++;
                if (namePropDescriptor === sampleLines.length || _RunInRootFrame$Deter === controlLines.length) for(namePropDescriptor = sampleLines.length - 1, _RunInRootFrame$Deter = controlLines.length - 1; 1 <= namePropDescriptor && 0 <= _RunInRootFrame$Deter && sampleLines[namePropDescriptor] !== controlLines[_RunInRootFrame$Deter];)_RunInRootFrame$Deter--;
                for(; 1 <= namePropDescriptor && 0 <= _RunInRootFrame$Deter; namePropDescriptor--, _RunInRootFrame$Deter--)if (sampleLines[namePropDescriptor] !== controlLines[_RunInRootFrame$Deter]) {
                    if (1 !== namePropDescriptor || 1 !== _RunInRootFrame$Deter) {
                        do if (namePropDescriptor--, _RunInRootFrame$Deter--, 0 > _RunInRootFrame$Deter || sampleLines[namePropDescriptor] !== controlLines[_RunInRootFrame$Deter]) {
                            var _frame = "\n" + sampleLines[namePropDescriptor].replace(" at new ", " at ");
                            fn.displayName && _frame.includes("<anonymous>") && (_frame = _frame.replace("<anonymous>", fn.displayName));
                            "function" === typeof fn && componentFrameCache.set(fn, _frame);
                            return _frame;
                        }
                        while (1 <= namePropDescriptor && 0 <= _RunInRootFrame$Deter)
                    }
                    break;
                }
            }
        } finally{
            reentry = !1, ReactSharedInternals.H = previousDispatcher, reenableLogs(), Error.prepareStackTrace = frame;
        }
        sampleLines = (sampleLines = fn ? fn.displayName || fn.name : "") ? describeBuiltInComponentFrame(sampleLines) : "";
        "function" === typeof fn && componentFrameCache.set(fn, sampleLines);
        return sampleLines;
    }
    function describeUnknownElementTypeFrameInDEV(type) {
        if (null == type) return "";
        if ("function" === typeof type) {
            var prototype = type.prototype;
            return describeNativeComponentFrame(type, !(!prototype || !prototype.isReactComponent));
        }
        if ("string" === typeof type) return describeBuiltInComponentFrame(type);
        switch(type){
            case REACT_SUSPENSE_TYPE:
                return describeBuiltInComponentFrame("Suspense");
            case REACT_SUSPENSE_LIST_TYPE:
                return describeBuiltInComponentFrame("SuspenseList");
        }
        if ("object" === typeof type) switch(type.$$typeof){
            case REACT_FORWARD_REF_TYPE:
                return type = describeNativeComponentFrame(type.render, !1), type;
            case REACT_MEMO_TYPE:
                return describeUnknownElementTypeFrameInDEV(type.type);
            case REACT_LAZY_TYPE:
                prototype = type._payload;
                type = type._init;
                try {
                    return describeUnknownElementTypeFrameInDEV(type(prototype));
                } catch (x) {}
        }
        return "";
    }
    function getOwner() {
        var dispatcher = ReactSharedInternals.A;
        return null === dispatcher ? null : dispatcher.getOwner();
    }
    function hasValidKey(config) {
        if (hasOwnProperty.call(config, "key")) {
            var getter = Object.getOwnPropertyDescriptor(config, "key").get;
            if (getter && getter.isReactWarning) return !1;
        }
        return void 0 !== config.key;
    }
    function defineKeyPropWarningGetter(props, displayName) {
        function warnAboutAccessingKey() {
            specialPropKeyWarningShown || (specialPropKeyWarningShown = !0, console.error("%s: `key` is not a prop. Trying to access it will result in `undefined` being returned. If you need to access the same value within the child component, you should pass it as a different prop. (https://react.dev/link/special-props)", displayName));
        }
        warnAboutAccessingKey.isReactWarning = !0;
        Object.defineProperty(props, "key", {
            get: warnAboutAccessingKey,
            configurable: !0
        });
    }
    function elementRefGetterWithDeprecationWarning() {
        var componentName = getComponentNameFromType(this.type);
        didWarnAboutElementRef[componentName] || (didWarnAboutElementRef[componentName] = !0, console.error("Accessing element.ref was removed in React 19. ref is now a regular prop. It will be removed from the JSX Element type in a future release."));
        componentName = this.props.ref;
        return void 0 !== componentName ? componentName : null;
    }
    function ReactElement(type, key, self, source, owner, props) {
        self = props.ref;
        type = {
            $$typeof: REACT_ELEMENT_TYPE,
            type: type,
            key: key,
            props: props,
            _owner: owner
        };
        null !== (void 0 !== self ? self : null) ? Object.defineProperty(type, "ref", {
            enumerable: !1,
            get: elementRefGetterWithDeprecationWarning
        }) : Object.defineProperty(type, "ref", {
            enumerable: !1,
            value: null
        });
        type._store = {};
        Object.defineProperty(type._store, "validated", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: 0
        });
        Object.defineProperty(type, "_debugInfo", {
            configurable: !1,
            enumerable: !1,
            writable: !0,
            value: null
        });
        Object.freeze && (Object.freeze(type.props), Object.freeze(type));
        return type;
    }
    function jsxDEVImpl(type, config, maybeKey, isStaticChildren, source, self) {
        if ("string" === typeof type || "function" === typeof type || type === REACT_FRAGMENT_TYPE || type === REACT_PROFILER_TYPE || type === REACT_STRICT_MODE_TYPE || type === REACT_SUSPENSE_TYPE || type === REACT_SUSPENSE_LIST_TYPE || type === REACT_OFFSCREEN_TYPE || "object" === typeof type && null !== type && (type.$$typeof === REACT_LAZY_TYPE || type.$$typeof === REACT_MEMO_TYPE || type.$$typeof === REACT_CONTEXT_TYPE || type.$$typeof === REACT_CONSUMER_TYPE || type.$$typeof === REACT_FORWARD_REF_TYPE || type.$$typeof === REACT_CLIENT_REFERENCE$1 || void 0 !== type.getModuleId)) {
            var children = config.children;
            if (void 0 !== children) if (isStaticChildren) if (isArrayImpl(children)) {
                for(isStaticChildren = 0; isStaticChildren < children.length; isStaticChildren++)validateChildKeys(children[isStaticChildren], type);
                Object.freeze && Object.freeze(children);
            } else console.error("React.jsx: Static children should always be an array. You are likely explicitly calling React.jsxs or React.jsxDEV. Use the Babel transform instead.");
            else validateChildKeys(children, type);
        } else {
            children = "";
            if (void 0 === type || "object" === typeof type && null !== type && 0 === Object.keys(type).length) children += " You likely forgot to export your component from the file it's defined in, or you might have mixed up default and named imports.";
            null === type ? isStaticChildren = "null" : isArrayImpl(type) ? isStaticChildren = "array" : void 0 !== type && type.$$typeof === REACT_ELEMENT_TYPE ? (isStaticChildren = "<" + (getComponentNameFromType(type.type) || "Unknown") + " />", children = " Did you accidentally export a JSX literal instead of a component?") : isStaticChildren = typeof type;
            console.error("React.jsx: type is invalid -- expected a string (for built-in components) or a class/function (for composite components) but got: %s.%s", isStaticChildren, children);
        }
        if (hasOwnProperty.call(config, "key")) {
            children = getComponentNameFromType(type);
            var keys = Object.keys(config).filter(function(k) {
                return "key" !== k;
            });
            isStaticChildren = 0 < keys.length ? "{key: someKey, " + keys.join(": ..., ") + ": ...}" : "{key: someKey}";
            didWarnAboutKeySpread[children + isStaticChildren] || (keys = 0 < keys.length ? "{" + keys.join(": ..., ") + ": ...}" : "{}", console.error('A props object containing a "key" prop is being spread into JSX:\n  let props = %s;\n  <%s {...props} />\nReact keys must be passed directly to JSX without using spread:\n  let props = %s;\n  <%s key={someKey} {...props} />', isStaticChildren, children, keys, children), didWarnAboutKeySpread[children + isStaticChildren] = !0);
        }
        children = null;
        void 0 !== maybeKey && (checkKeyStringCoercion(maybeKey), children = "" + maybeKey);
        hasValidKey(config) && (checkKeyStringCoercion(config.key), children = "" + config.key);
        if ("key" in config) {
            maybeKey = {};
            for(var propName in config)"key" !== propName && (maybeKey[propName] = config[propName]);
        } else maybeKey = config;
        children && defineKeyPropWarningGetter(maybeKey, "function" === typeof type ? type.displayName || type.name || "Unknown" : type);
        return ReactElement(type, children, self, source, getOwner(), maybeKey);
    }
    function validateChildKeys(node, parentType) {
        if ("object" === typeof node && node && node.$$typeof !== REACT_CLIENT_REFERENCE) {
            if (isArrayImpl(node)) for(var i = 0; i < node.length; i++){
                var child = node[i];
                isValidElement(child) && validateExplicitKey(child, parentType);
            }
            else if (isValidElement(node)) node._store && (node._store.validated = 1);
            else if (null === node || "object" !== typeof node ? i = null : (i = MAYBE_ITERATOR_SYMBOL && node[MAYBE_ITERATOR_SYMBOL] || node["@@iterator"], i = "function" === typeof i ? i : null), "function" === typeof i && i !== node.entries && (i = i.call(node), i !== node)) for(; !(node = i.next()).done;)isValidElement(node.value) && validateExplicitKey(node.value, parentType);
        }
    }
    function isValidElement(object) {
        return "object" === typeof object && null !== object && object.$$typeof === REACT_ELEMENT_TYPE;
    }
    function validateExplicitKey(element, parentType) {
        if (element._store && !element._store.validated && null == element.key && (element._store.validated = 1, parentType = getCurrentComponentErrorInfo(parentType), !ownerHasKeyUseWarning[parentType])) {
            ownerHasKeyUseWarning[parentType] = !0;
            var childOwner = "";
            element && null != element._owner && element._owner !== getOwner() && (childOwner = null, "number" === typeof element._owner.tag ? childOwner = getComponentNameFromType(element._owner.type) : "string" === typeof element._owner.name && (childOwner = element._owner.name), childOwner = " It was passed a child from " + childOwner + ".");
            var prevGetCurrentStack = ReactSharedInternals.getCurrentStack;
            ReactSharedInternals.getCurrentStack = function() {
                var stack = describeUnknownElementTypeFrameInDEV(element.type);
                prevGetCurrentStack && (stack += prevGetCurrentStack() || "");
                return stack;
            };
            console.error('Each child in a list should have a unique "key" prop.%s%s See https://react.dev/link/warning-keys for more information.', parentType, childOwner);
            ReactSharedInternals.getCurrentStack = prevGetCurrentStack;
        }
    }
    function getCurrentComponentErrorInfo(parentType) {
        var info = "", owner = getOwner();
        owner && (owner = getComponentNameFromType(owner.type)) && (info = "\n\nCheck the render method of `" + owner + "`.");
        info || (parentType = getComponentNameFromType(parentType)) && (info = "\n\nCheck the top-level render call using <" + parentType + ">.");
        return info;
    }
    var React = __turbopack_require__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)"), REACT_ELEMENT_TYPE = Symbol.for("react.transitional.element"), REACT_PORTAL_TYPE = Symbol.for("react.portal"), REACT_FRAGMENT_TYPE = Symbol.for("react.fragment"), REACT_STRICT_MODE_TYPE = Symbol.for("react.strict_mode"), REACT_PROFILER_TYPE = Symbol.for("react.profiler");
    Symbol.for("react.provider");
    var REACT_CONSUMER_TYPE = Symbol.for("react.consumer"), REACT_CONTEXT_TYPE = Symbol.for("react.context"), REACT_FORWARD_REF_TYPE = Symbol.for("react.forward_ref"), REACT_SUSPENSE_TYPE = Symbol.for("react.suspense"), REACT_SUSPENSE_LIST_TYPE = Symbol.for("react.suspense_list"), REACT_MEMO_TYPE = Symbol.for("react.memo"), REACT_LAZY_TYPE = Symbol.for("react.lazy"), REACT_OFFSCREEN_TYPE = Symbol.for("react.offscreen"), MAYBE_ITERATOR_SYMBOL = Symbol.iterator, REACT_CLIENT_REFERENCE$2 = Symbol.for("react.client.reference"), ReactSharedInternals = React.__CLIENT_INTERNALS_DO_NOT_USE_OR_WARN_USERS_THEY_CANNOT_UPGRADE, hasOwnProperty = Object.prototype.hasOwnProperty, assign = Object.assign, REACT_CLIENT_REFERENCE$1 = Symbol.for("react.client.reference"), isArrayImpl = Array.isArray, disabledDepth = 0, prevLog, prevInfo, prevWarn, prevError, prevGroup, prevGroupCollapsed, prevGroupEnd;
    disabledLog.__reactDisabledLog = !0;
    var prefix, suffix, reentry = !1;
    var componentFrameCache = new ("function" === typeof WeakMap ? WeakMap : Map)();
    var REACT_CLIENT_REFERENCE = Symbol.for("react.client.reference"), specialPropKeyWarningShown;
    var didWarnAboutElementRef = {};
    var didWarnAboutKeySpread = {}, ownerHasKeyUseWarning = {};
    exports.Fragment = REACT_FRAGMENT_TYPE;
    exports.jsxDEV = function(type, config, maybeKey, isStaticChildren, source, self) {
        return jsxDEVImpl(type, config, maybeKey, isStaticChildren, source, self);
    };
}();
}}),
"[project]/node_modules/next/dist/compiled/react/jsx-dev-runtime.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$build$2f$polyfills$2f$process$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/build/polyfills/process.js [app-client] (ecmascript)");
'use strict';
if ("TURBOPACK compile-time falsy", 0) {
    "TURBOPACK unreachable";
} else {
    module.exports = __turbopack_require__("[project]/node_modules/next/dist/compiled/react/cjs/react-jsx-dev-runtime.development.js [app-client] (ecmascript)");
}
}}),
"[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)": (function(__turbopack_context__) {

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, m: module, e: exports, t: __turbopack_require_real__ } = __turbopack_context__;
{
"use strict";
Object.defineProperty(exports, "__esModule", {
    value: true
});
Object.defineProperty(exports, "default", {
    enumerable: true,
    get: function() {
        return NoopHead;
    }
});
function NoopHead() {
    return null;
}
if ((typeof exports.default === 'function' || typeof exports.default === 'object' && exports.default !== null) && typeof exports.default.__esModule === 'undefined') {
    Object.defineProperty(exports.default, '__esModule', {
        value: true
    });
    Object.assign(exports.default, exports);
    module.exports = exports.default;
} //# sourceMappingURL=noop-head.js.map
}}),
"[project]/node_modules/next-seo/lib/next-seo.module.js [app-client] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { r: __turbopack_require__, f: __turbopack_module_context__, i: __turbopack_import__, s: __turbopack_esm__, v: __turbopack_export_value__, n: __turbopack_export_namespace__, c: __turbopack_cache__, M: __turbopack_modules__, l: __turbopack_load__, j: __turbopack_dynamic__, P: __turbopack_resolve_absolute_path__, U: __turbopack_relative_url__, R: __turbopack_resolve_module_id_path__, b: __turbopack_worker_blob_url__, g: global, __dirname, z: __turbopack_require_stub__ } = __turbopack_context__;
{
__turbopack_esm__({
    "ArticleJsonLd": (()=>ArticleJsonLd),
    "BrandJsonLd": (()=>BrandJsonLd),
    "BreadcrumbJsonLd": (()=>BreadCrumbJsonLd),
    "CampgroundJsonLd": (()=>CampgroundJsonLd),
    "CarouselJsonLd": (()=>CarouselJsonLd),
    "CollectionPageJsonLd": (()=>CollectionPageJsonLd),
    "CorporateContactJsonLd": (()=>CorporateContactJsonLd),
    "CourseJsonLd": (()=>CourseJsonLd),
    "DatasetJsonLd": (()=>DatasetJsonLd),
    "DefaultSeo": (()=>DefaultSeo),
    "EventJsonLd": (()=>EventJsonLd),
    "FAQPageJsonLd": (()=>FAQPageJsonLd),
    "HowToJsonLd": (()=>howToJsonLd),
    "ImageJsonLd": (()=>ImageJsonLd),
    "JobPostingJsonLd": (()=>JobPostingJsonLd),
    "LocalBusinessJsonLd": (()=>LocalBusinessJsonLd),
    "LogoJsonLd": (()=>LogoJsonLd),
    "NewsArticleJsonLd": (()=>NewsArticleJsonLd),
    "NextSeo": (()=>NextSeo),
    "OrganizationJsonLd": (()=>OrganizationJsonLd),
    "ParkJsonLd": (()=>ParkJsonLd),
    "ProductJsonLd": (()=>ProductJsonLd),
    "ProfilePageJsonLd": (()=>ProfilePageJsonLd),
    "QAPageJsonLd": (()=>QAPageJsonLd),
    "RecipeJsonLd": (()=>RecipeJsonLd),
    "SiteLinksSearchBoxJsonLd": (()=>SiteLinksSearchBoxJsonLd),
    "SocialProfileJsonLd": (()=>SocialProfileJsonLd),
    "SoftwareAppJsonLd": (()=>SoftwareAppJsonLd),
    "VideoGameJsonLd": (()=>VideoGameJsonLd),
    "VideoJsonLd": (()=>VideoJsonLd),
    "WebPageJsonLd": (()=>WebPageJsonLd)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/compiled/react/index.js [app-client] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__ = __turbopack_import__("[project]/node_modules/next/dist/client/components/noop-head.js [app-client] (ecmascript)");
;
;
function _extends() {
    _extends = ("TURBOPACK compile-time truthy", 1) ? Object.assign.bind() : ("TURBOPACK unreachable", undefined);
    return _extends.apply(this, arguments);
}
function _objectWithoutPropertiesLoose(source, excluded) {
    if (source == null) return {};
    var target = {};
    var sourceKeys = Object.keys(source);
    var key, i;
    for(i = 0; i < sourceKeys.length; i++){
        key = sourceKeys[i];
        if (excluded.indexOf(key) >= 0) continue;
        target[key] = source[key];
    }
    return target;
}
var _excluded$z = [
    "keyOverride"
], _excluded2$2 = [
    "crossOrigin"
];
var defaults = {
    templateTitle: '',
    noindex: false,
    nofollow: false,
    norobots: false,
    defaultOpenGraphImageWidth: 0,
    defaultOpenGraphImageHeight: 0,
    defaultOpenGraphVideoWidth: 0,
    defaultOpenGraphVideoHeight: 0
};
var buildOpenGraphMediaTags = function buildOpenGraphMediaTags(mediaType, media, _temp) {
    if (media === void 0) {
        media = [];
    }
    var _ref = _temp === void 0 ? {} : _temp, defaultWidth = _ref.defaultWidth, defaultHeight = _ref.defaultHeight;
    return media.reduce(function(tags, medium, index) {
        tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "og:" + mediaType + ":0" + index,
            property: "og:" + mediaType,
            content: medium.url
        }));
        if (medium.alt) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":alt0" + index,
                property: "og:" + mediaType + ":alt",
                content: medium.alt
            }));
        }
        if (medium.secureUrl) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":secure_url0" + index,
                property: "og:" + mediaType + ":secure_url",
                content: medium.secureUrl.toString()
            }));
        }
        if (medium.type) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":type0" + index,
                property: "og:" + mediaType + ":type",
                content: medium.type.toString()
            }));
        }
        if (medium.width) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":width0" + index,
                property: "og:" + mediaType + ":width",
                content: medium.width.toString()
            }));
        } else if (defaultWidth) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":width0" + index,
                property: "og:" + mediaType + ":width",
                content: defaultWidth.toString()
            }));
        }
        if (medium.height) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":height" + index,
                property: "og:" + mediaType + ":height",
                content: medium.height.toString()
            }));
        } else if (defaultHeight) {
            tags.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:" + mediaType + ":height" + index,
                property: "og:" + mediaType + ":height",
                content: defaultHeight.toString()
            }));
        }
        return tags;
    }, []);
};
var buildTags = function buildTags(config) {
    var _config$openGraph, _config$openGraph3, _config$additionalLin;
    var tagsToRender = [];
    if (config.titleTemplate) {
        defaults.templateTitle = config.titleTemplate;
    }
    var updatedTitle = '';
    if (config.title) {
        updatedTitle = config.title;
        if (defaults.templateTitle) {
            updatedTitle = defaults.templateTitle.replace(/%s/g, function() {
                return updatedTitle;
            });
        }
    } else if (config.defaultTitle) {
        updatedTitle = config.defaultTitle;
    }
    if (updatedTitle) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("title", {
            key: "title"
        }, updatedTitle));
    }
    var noindex = config.noindex === undefined ? defaults.noindex || config.dangerouslySetAllPagesToNoIndex : config.noindex;
    var nofollow = config.nofollow === undefined ? defaults.nofollow || config.dangerouslySetAllPagesToNoFollow : config.nofollow;
    var norobots = config.norobots || defaults.norobots;
    var robotsParams = '';
    if (config.robotsProps) {
        var _config$robotsProps = config.robotsProps, nosnippet = _config$robotsProps.nosnippet, maxSnippet = _config$robotsProps.maxSnippet, maxImagePreview = _config$robotsProps.maxImagePreview, maxVideoPreview = _config$robotsProps.maxVideoPreview, noarchive = _config$robotsProps.noarchive, noimageindex = _config$robotsProps.noimageindex, notranslate = _config$robotsProps.notranslate, unavailableAfter = _config$robotsProps.unavailableAfter;
        robotsParams = "" + (nosnippet ? ',nosnippet' : '') + (maxSnippet ? ",max-snippet:" + maxSnippet : '') + (maxImagePreview ? ",max-image-preview:" + maxImagePreview : '') + (noarchive ? ',noarchive' : '') + (unavailableAfter ? ",unavailable_after:" + unavailableAfter : '') + (noimageindex ? ',noimageindex' : '') + (maxVideoPreview ? ",max-video-preview:" + maxVideoPreview : '') + (notranslate ? ',notranslate' : '');
    }
    if (config.norobots) {
        defaults.norobots = true;
    }
    if (noindex || nofollow) {
        if (config.dangerouslySetAllPagesToNoIndex) {
            defaults.noindex = true;
        }
        if (config.dangerouslySetAllPagesToNoFollow) {
            defaults.nofollow = true;
        }
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "robots",
            name: "robots",
            content: (noindex ? 'noindex' : 'index') + "," + (nofollow ? 'nofollow' : 'follow') + robotsParams
        }));
    } else if (!norobots || robotsParams) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "robots",
            name: "robots",
            content: "index,follow" + robotsParams
        }));
    }
    if (config.description) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "description",
            name: "description",
            content: config.description
        }));
    }
    if (config.themeColor) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "theme-color",
            name: "theme-color",
            content: config.themeColor
        }));
    }
    if (config.mobileAlternate) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("link", {
            rel: "alternate",
            key: "mobileAlternate",
            media: config.mobileAlternate.media,
            href: config.mobileAlternate.href
        }));
    }
    if (config.languageAlternates && config.languageAlternates.length > 0) {
        config.languageAlternates.forEach(function(languageAlternate) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("link", {
                rel: "alternate",
                key: "languageAlternate-" + languageAlternate.hrefLang,
                hrefLang: languageAlternate.hrefLang,
                href: languageAlternate.href
            }));
        });
    }
    if (config.twitter) {
        if (config.twitter.cardType) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "twitter:card",
                name: "twitter:card",
                content: config.twitter.cardType
            }));
        }
        if (config.twitter.site) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "twitter:site",
                name: "twitter:site",
                content: config.twitter.site
            }));
        }
        if (config.twitter.handle) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "twitter:creator",
                name: "twitter:creator",
                content: config.twitter.handle
            }));
        }
    }
    if (config.facebook) {
        if (config.facebook.appId) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "fb:app_id",
                property: "fb:app_id",
                content: config.facebook.appId
            }));
        }
    }
    if ((_config$openGraph = config.openGraph) != null && _config$openGraph.title || updatedTitle) {
        var _config$openGraph2;
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "og:title",
            property: "og:title",
            content: ((_config$openGraph2 = config.openGraph) == null ? void 0 : _config$openGraph2.title) || updatedTitle
        }));
    }
    if ((_config$openGraph3 = config.openGraph) != null && _config$openGraph3.description || config.description) {
        var _config$openGraph4;
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
            key: "og:description",
            property: "og:description",
            content: ((_config$openGraph4 = config.openGraph) == null ? void 0 : _config$openGraph4.description) || config.description
        }));
    }
    if (config.openGraph) {
        if (config.openGraph.url || config.canonical) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:url",
                property: "og:url",
                content: config.openGraph.url || config.canonical
            }));
        }
        if (config.openGraph.type) {
            var type = config.openGraph.type.toLowerCase();
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:type",
                property: "og:type",
                content: type
            }));
            if (type === 'profile' && config.openGraph.profile) {
                if (config.openGraph.profile.firstName) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "profile:first_name",
                        property: "profile:first_name",
                        content: config.openGraph.profile.firstName
                    }));
                }
                if (config.openGraph.profile.lastName) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "profile:last_name",
                        property: "profile:last_name",
                        content: config.openGraph.profile.lastName
                    }));
                }
                if (config.openGraph.profile.username) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "profile:username",
                        property: "profile:username",
                        content: config.openGraph.profile.username
                    }));
                }
                if (config.openGraph.profile.gender) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "profile:gender",
                        property: "profile:gender",
                        content: config.openGraph.profile.gender
                    }));
                }
            } else if (type === 'book' && config.openGraph.book) {
                if (config.openGraph.book.authors && config.openGraph.book.authors.length) {
                    config.openGraph.book.authors.forEach(function(author, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "book:author:0" + index,
                            property: "book:author",
                            content: author
                        }));
                    });
                }
                if (config.openGraph.book.isbn) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "book:isbn",
                        property: "book:isbn",
                        content: config.openGraph.book.isbn
                    }));
                }
                if (config.openGraph.book.releaseDate) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "book:release_date",
                        property: "book:release_date",
                        content: config.openGraph.book.releaseDate
                    }));
                }
                if (config.openGraph.book.tags && config.openGraph.book.tags.length) {
                    config.openGraph.book.tags.forEach(function(tag, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "book:tag:0" + index,
                            property: "book:tag",
                            content: tag
                        }));
                    });
                }
            } else if (type === 'article' && config.openGraph.article) {
                if (config.openGraph.article.publishedTime) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "article:published_time",
                        property: "article:published_time",
                        content: config.openGraph.article.publishedTime
                    }));
                }
                if (config.openGraph.article.modifiedTime) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "article:modified_time",
                        property: "article:modified_time",
                        content: config.openGraph.article.modifiedTime
                    }));
                }
                if (config.openGraph.article.expirationTime) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "article:expiration_time",
                        property: "article:expiration_time",
                        content: config.openGraph.article.expirationTime
                    }));
                }
                if (config.openGraph.article.authors && config.openGraph.article.authors.length) {
                    config.openGraph.article.authors.forEach(function(author, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "article:author:0" + index,
                            property: "article:author",
                            content: author
                        }));
                    });
                }
                if (config.openGraph.article.section) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "article:section",
                        property: "article:section",
                        content: config.openGraph.article.section
                    }));
                }
                if (config.openGraph.article.tags && config.openGraph.article.tags.length) {
                    config.openGraph.article.tags.forEach(function(tag, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "article:tag:0" + index,
                            property: "article:tag",
                            content: tag
                        }));
                    });
                }
            } else if ((type === 'video.movie' || type === 'video.episode' || type === 'video.tv_show' || type === 'video.other') && config.openGraph.video) {
                if (config.openGraph.video.actors && config.openGraph.video.actors.length) {
                    config.openGraph.video.actors.forEach(function(actor, index) {
                        if (actor.profile) {
                            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                                key: "video:actor:0" + index,
                                property: "video:actor",
                                content: actor.profile
                            }));
                        }
                        if (actor.role) {
                            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                                key: "video:actor:role:0" + index,
                                property: "video:actor:role",
                                content: actor.role
                            }));
                        }
                    });
                }
                if (config.openGraph.video.directors && config.openGraph.video.directors.length) {
                    config.openGraph.video.directors.forEach(function(director, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "video:director:0" + index,
                            property: "video:director",
                            content: director
                        }));
                    });
                }
                if (config.openGraph.video.writers && config.openGraph.video.writers.length) {
                    config.openGraph.video.writers.forEach(function(writer, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "video:writer:0" + index,
                            property: "video:writer",
                            content: writer
                        }));
                    });
                }
                if (config.openGraph.video.duration) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "video:duration",
                        property: "video:duration",
                        content: config.openGraph.video.duration.toString()
                    }));
                }
                if (config.openGraph.video.releaseDate) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "video:release_date",
                        property: "video:release_date",
                        content: config.openGraph.video.releaseDate
                    }));
                }
                if (config.openGraph.video.tags && config.openGraph.video.tags.length) {
                    config.openGraph.video.tags.forEach(function(tag, index) {
                        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                            key: "video:tag:0" + index,
                            property: "video:tag",
                            content: tag
                        }));
                    });
                }
                if (config.openGraph.video.series) {
                    tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                        key: "video:series",
                        property: "video:series",
                        content: config.openGraph.video.series
                    }));
                }
            }
        }
        // images
        if (config.defaultOpenGraphImageWidth) {
            defaults.defaultOpenGraphImageWidth = config.defaultOpenGraphImageWidth;
        }
        if (config.defaultOpenGraphImageHeight) {
            defaults.defaultOpenGraphImageHeight = config.defaultOpenGraphImageHeight;
        }
        if (config.openGraph.images && config.openGraph.images.length) {
            tagsToRender.push.apply(tagsToRender, buildOpenGraphMediaTags('image', config.openGraph.images, {
                defaultWidth: defaults.defaultOpenGraphImageWidth,
                defaultHeight: defaults.defaultOpenGraphImageHeight
            }));
        }
        // videos
        if (config.defaultOpenGraphVideoWidth) {
            defaults.defaultOpenGraphVideoWidth = config.defaultOpenGraphVideoWidth;
        }
        if (config.defaultOpenGraphVideoHeight) {
            defaults.defaultOpenGraphVideoHeight = config.defaultOpenGraphVideoHeight;
        }
        if (config.openGraph.videos && config.openGraph.videos.length) {
            tagsToRender.push.apply(tagsToRender, buildOpenGraphMediaTags('video', config.openGraph.videos, {
                defaultWidth: defaults.defaultOpenGraphVideoWidth,
                defaultHeight: defaults.defaultOpenGraphVideoHeight
            }));
        }
        // audio
        if (config.openGraph.audio) {
            tagsToRender.push.apply(tagsToRender, buildOpenGraphMediaTags('audio', config.openGraph.audio));
        }
        if (config.openGraph.locale) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:locale",
                property: "og:locale",
                content: config.openGraph.locale
            }));
        }
        if (config.openGraph.siteName || config.openGraph.site_name) {
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", {
                key: "og:site_name",
                property: "og:site_name",
                content: config.openGraph.siteName || config.openGraph.site_name
            }));
        }
    }
    if (config.canonical) {
        tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("link", {
            rel: "canonical",
            href: config.canonical,
            key: "canonical"
        }));
    }
    if (config.additionalMetaTags && config.additionalMetaTags.length > 0) {
        config.additionalMetaTags.forEach(function(_ref2) {
            var _ref3, _ref4;
            var keyOverride = _ref2.keyOverride, tag = _objectWithoutPropertiesLoose(_ref2, _excluded$z);
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("meta", _extends({
                key: "meta:" + ((_ref3 = (_ref4 = keyOverride != null ? keyOverride : tag.name) != null ? _ref4 : tag.property) != null ? _ref3 : tag.httpEquiv)
            }, tag)));
        });
    }
    if ((_config$additionalLin = config.additionalLinkTags) != null && _config$additionalLin.length) {
        config.additionalLinkTags.forEach(function(tag) {
            var _rest$keyOverride;
            var tagCrossOrigin = tag.crossOrigin, rest = _objectWithoutPropertiesLoose(tag, _excluded2$2);
            var crossOrigin = tagCrossOrigin === 'anonymous' || tagCrossOrigin === 'use-credentials' || tagCrossOrigin === '' ? tagCrossOrigin : undefined;
            tagsToRender.push(/*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("link", _extends({
                key: "link" + ((_rest$keyOverride = rest.keyOverride) != null ? _rest$keyOverride : rest.href) + rest.rel
            }, rest, {
                crossOrigin: crossOrigin
            })));
        });
    }
    return tagsToRender;
};
var WithHead = function WithHead(props) {
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null, buildTags(props));
};
var DefaultSeo = function DefaultSeo(_ref) {
    var title = _ref.title, titleTemplate = _ref.titleTemplate, defaultTitle = _ref.defaultTitle, themeColor = _ref.themeColor, _ref$dangerouslySetAl = _ref.dangerouslySetAllPagesToNoIndex, dangerouslySetAllPagesToNoIndex = _ref$dangerouslySetAl === void 0 ? false : _ref$dangerouslySetAl, _ref$dangerouslySetAl2 = _ref.dangerouslySetAllPagesToNoFollow, dangerouslySetAllPagesToNoFollow = _ref$dangerouslySetAl2 === void 0 ? false : _ref$dangerouslySetAl2, description = _ref.description, canonical = _ref.canonical, facebook = _ref.facebook, openGraph = _ref.openGraph, additionalMetaTags = _ref.additionalMetaTags, twitter = _ref.twitter, defaultOpenGraphImageWidth = _ref.defaultOpenGraphImageWidth, defaultOpenGraphImageHeight = _ref.defaultOpenGraphImageHeight, defaultOpenGraphVideoWidth = _ref.defaultOpenGraphVideoWidth, defaultOpenGraphVideoHeight = _ref.defaultOpenGraphVideoHeight, mobileAlternate = _ref.mobileAlternate, languageAlternates = _ref.languageAlternates, additionalLinkTags = _ref.additionalLinkTags, robotsProps = _ref.robotsProps, norobots = _ref.norobots;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(WithHead, {
        title: title,
        titleTemplate: titleTemplate,
        defaultTitle: defaultTitle,
        themeColor: themeColor,
        dangerouslySetAllPagesToNoIndex: dangerouslySetAllPagesToNoIndex,
        dangerouslySetAllPagesToNoFollow: dangerouslySetAllPagesToNoFollow,
        description: description,
        canonical: canonical,
        facebook: facebook,
        openGraph: openGraph,
        additionalMetaTags: additionalMetaTags,
        twitter: twitter,
        defaultOpenGraphImageWidth: defaultOpenGraphImageWidth,
        defaultOpenGraphImageHeight: defaultOpenGraphImageHeight,
        defaultOpenGraphVideoWidth: defaultOpenGraphVideoWidth,
        defaultOpenGraphVideoHeight: defaultOpenGraphVideoHeight,
        mobileAlternate: mobileAlternate,
        languageAlternates: languageAlternates,
        additionalLinkTags: additionalLinkTags,
        robotsProps: robotsProps,
        norobots: norobots
    });
};
var NextSeo = function NextSeo(_ref) {
    var title = _ref.title, themeColor = _ref.themeColor, noindex = _ref.noindex, nofollow = _ref.nofollow, robotsProps = _ref.robotsProps, description = _ref.description, canonical = _ref.canonical, openGraph = _ref.openGraph, facebook = _ref.facebook, twitter = _ref.twitter, additionalMetaTags = _ref.additionalMetaTags, titleTemplate = _ref.titleTemplate, defaultTitle = _ref.defaultTitle, mobileAlternate = _ref.mobileAlternate, languageAlternates = _ref.languageAlternates, additionalLinkTags = _ref.additionalLinkTags;
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].Fragment, null, /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(WithHead, {
        title: title,
        themeColor: themeColor,
        noindex: noindex,
        nofollow: nofollow,
        robotsProps: robotsProps,
        description: description,
        canonical: canonical,
        facebook: facebook,
        openGraph: openGraph,
        additionalMetaTags: additionalMetaTags,
        twitter: twitter,
        titleTemplate: titleTemplate,
        defaultTitle: defaultTitle,
        mobileAlternate: mobileAlternate,
        languageAlternates: languageAlternates,
        additionalLinkTags: additionalLinkTags
    }));
};
var toJson = function toJson(type, jsonld) {
    var data = jsonld;
    if (Array.isArray(data) && data.length === 1) {
        data = _extends({}, jsonld[0]);
    }
    var jsonLdObject = Array.isArray(data) ? data.map(function(item) {
        return formatObjectForSchema(type, item);
    }) : formatObjectForSchema(type, data);
    return {
        __html: JSON.stringify(jsonLdObject, safeJsonLdReplacer)
    };
};
var formatObjectForSchema = function formatObjectForSchema(type, jsonld) {
    var _jsonld$id = jsonld.id, id = _jsonld$id === void 0 ? undefined : _jsonld$id;
    var updated = _extends({}, id ? {
        '@id': jsonld.id
    } : {}, jsonld);
    delete updated.id;
    return _extends({
        '@context': 'https://schema.org',
        '@type': type
    }, updated);
};
var ESCAPE_ENTITIES = Object.freeze({
    '&': '&amp;',
    '<': '&lt;',
    '>': '&gt;',
    '"': '&quot;',
    "'": '&apos;'
});
var ESCAPE_REGEX = new RegExp("[" + Object.keys(ESCAPE_ENTITIES).join('') + "]", 'g');
var ESCAPE_REPLACER = function ESCAPE_REPLACER(t) {
    return ESCAPE_ENTITIES[t];
};
/**
 * A replacer for JSON.stringify to strip JSON-LD of illegal HTML entities
 * per https://www.w3.org/TR/json-ld11/#restrictions-for-contents-of-json-ld-script-elements
 */ var safeJsonLdReplacer = function() {
    // Replace per https://www.w3.org/TR/json-ld11/#restrictions-for-contents-of-json-ld-script-elements
    // Solution from https://stackoverflow.com/a/5499821/864313
    return function(_, value) {
        switch(typeof value){
            case 'object':
                // Omit null values.
                if (value === null) {
                    return undefined;
                }
                return value;
            // JSON.stringify will recursively call replacer.
            case 'number':
            case 'boolean':
            case 'bigint':
                return value;
            // These values are not risky.
            case 'string':
                return value.replace(ESCAPE_REGEX, ESCAPE_REPLACER);
            default:
                {
                    // JSON.stringify will remove this element.
                    return undefined;
                }
        }
    };
}();
var _excluded$y = [
    "type",
    "keyOverride",
    "scriptKey",
    "scriptId",
    "dataArray",
    "useAppDir"
];
function JsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Thing' : _ref$type, keyOverride = _ref.keyOverride, scriptKey = _ref.scriptKey, _ref$scriptId = _ref.scriptId, scriptId = _ref$scriptId === void 0 ? undefined : _ref$scriptId, dataArray = _ref.dataArray, _ref$useAppDir = _ref.useAppDir, useAppDir = _ref$useAppDir === void 0 ? false : _ref$useAppDir, rest = _objectWithoutPropertiesLoose(_ref, _excluded$y);
    var JsonLdScript = function JsonLdScript() {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement("script", {
            type: "application/ld+json",
            id: scriptId,
            "data-testid": scriptId,
            dangerouslySetInnerHTML: toJson(type, dataArray === undefined ? _extends({}, rest) : dataArray),
            key: "jsonld-" + scriptKey + (keyOverride ? "-" + keyOverride : '')
        });
    };
    if (useAppDir) {
        return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLdScript, null);
    }
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(__TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$client$2f$components$2f$noop$2d$head$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"], null, JsonLdScript());
}
/**
 * Generate author information
 * @param author
 * @returns
 */ function generateAuthorInfo(author) {
    if (typeof author === 'string') {
        return {
            '@type': 'Person',
            name: author
        };
    } else if (!!author.name) {
        var _author$type;
        return {
            '@type': (_author$type = author == null ? void 0 : author.type) != null ? _author$type : 'Person',
            name: author.name,
            url: author == null ? void 0 : author.url
        };
    }
    return;
}
function setAuthor(author) {
    if (Array.isArray(author)) {
        return author.map(function(item) {
            return generateAuthorInfo(item);
        }).filter(function(item) {
            return !!item;
        });
    } else if (author) {
        return generateAuthorInfo(author);
    }
    return;
}
function setImage(image) {
    if (image) {
        return {
            '@type': 'ImageObject',
            url: image
        };
    }
    return undefined;
}
function setPublisher(publisherName, publisherLogo) {
    if (!publisherName) {
        return undefined;
    }
    return {
        '@type': 'Organization',
        name: publisherName,
        logo: setImage(publisherLogo)
    };
}
function setReviewRating(rating) {
    if (rating) {
        return _extends({}, rating, {
            '@type': 'Rating'
        });
    }
    return undefined;
}
var _excluded$x = [
    "reviewRating",
    "author",
    "publisher"
];
function setReviews(reviews) {
    function mapReview(_ref) {
        var reviewRating = _ref.reviewRating, author = _ref.author, publisher = _ref.publisher, rest = _objectWithoutPropertiesLoose(_ref, _excluded$x);
        return _extends({}, rest, {
            '@type': 'Review'
        }, author && {
            author: setAuthor(author)
        }, reviewRating && {
            reviewRating: setReviewRating(reviewRating)
        }, publisher && {
            publisher: setPublisher(publisher.name)
        });
    }
    if (Array.isArray(reviews)) {
        return reviews.map(mapReview);
    } else if (reviews) {
        return mapReview(reviews);
    }
    return undefined;
}
function setNutrition(calories) {
    if (calories) {
        return {
            '@type': 'NutritionInformation',
            calories: calories + " calories"
        };
    }
    return undefined;
}
function setAggregateRating(aggregateRating) {
    if (aggregateRating) {
        return {
            '@type': 'AggregateRating',
            ratingCount: aggregateRating.ratingCount,
            reviewCount: aggregateRating.reviewCount,
            bestRating: aggregateRating.bestRating,
            ratingValue: aggregateRating.ratingValue,
            worstRating: aggregateRating.worstRating
        };
    }
    return undefined;
}
function setClip(clips) {
    function mapClip(clip) {
        return _extends({}, clip, {
            '@type': 'Clip'
        });
    }
    if (Array.isArray(clips)) {
        return clips.map(mapClip);
    } else if (clips) {
        return mapClip(clips);
    }
    return undefined;
}
function setInteractionStatistic(watchCount) {
    if (watchCount) {
        return {
            '@type': 'InteractionCounter',
            interactionType: 'https://schema.org/WatchAction',
            userInteractionCount: watchCount
        };
    }
    return undefined;
}
function setBroadcastEvent(publication) {
    function mapBroadcastEvent(publication) {
        return _extends({}, publication, {
            '@type': 'BroadcastEvent'
        });
    }
    if (publication) {
        if (Array.isArray(publication)) {
            return publication.map(mapBroadcastEvent);
        }
        return mapBroadcastEvent(publication);
    }
    return undefined;
}
var _excluded$w = [
    "thumbnailUrls",
    "hasPart",
    "watchCount",
    "publication"
];
function setVideo(video, setContext) {
    if (setContext === void 0) {
        setContext = false;
    }
    function mapVideo(_ref, context) {
        var thumbnailUrls = _ref.thumbnailUrls, hasPart = _ref.hasPart, watchCount = _ref.watchCount, publication = _ref.publication, rest = _objectWithoutPropertiesLoose(_ref, _excluded$w);
        return _extends({}, rest, {
            '@type': 'VideoObject'
        }, context && {
            '@context': 'https://schema.org'
        }, {
            thumbnailUrl: thumbnailUrls,
            hasPart: setClip(hasPart),
            interactionStatistic: setInteractionStatistic(watchCount),
            publication: setBroadcastEvent(publication)
        });
    }
    if (video) {
        return mapVideo(video, setContext);
    }
    return undefined;
}
function setInstruction(instruction) {
    if (instruction) {
        return _extends({}, instruction, {
            '@type': 'HowToStep'
        });
    }
    return undefined;
}
var _excluded$v = [
    "type",
    "keyOverride",
    "ofType",
    "data"
], _excluded2$1 = [
    "authorName",
    "images",
    "yields",
    "category",
    "calories",
    "aggregateRating",
    "video",
    "ingredients",
    "instructions",
    "cuisine"
];
function CarouselJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Carousel' : _ref$type, keyOverride = _ref.keyOverride, ofType = _ref.ofType, data = _ref.data, rest = _objectWithoutPropertiesLoose(_ref, _excluded$v);
    function generateList(data, ofType) {
        switch(ofType){
            case 'default':
                return data.map(function(item, index) {
                    return {
                        '@type': 'ListItem',
                        position: "" + (index + 1),
                        url: item.url
                    };
                });
            case 'course':
                return data.map(function(item, index) {
                    return {
                        '@type': 'ListItem',
                        position: "" + (index + 1),
                        item: {
                            '@context': 'https://schema.org',
                            '@type': 'Course',
                            url: item.url,
                            name: item.courseName,
                            description: item.description,
                            provider: {
                                '@type': 'Organization',
                                name: item.providerName,
                                sameAs: item.providerUrl
                            }
                        }
                    };
                });
            case 'movie':
                return data.map(function(item, index) {
                    return {
                        '@type': 'ListItem',
                        position: "" + (index + 1),
                        item: {
                            '@context': 'https://schema.org',
                            '@type': 'Movie',
                            name: item.name,
                            url: item.url,
                            image: item.image,
                            dateCreated: item.dateCreated,
                            director: item.director ? Array.isArray(item.director) ? item.director.map(function(director) {
                                return {
                                    '@type': 'Person',
                                    name: director.name
                                };
                            }) : {
                                '@type': 'Person',
                                name: item.director.name
                            } : undefined,
                            review: setReviews(item.review)
                        }
                    };
                });
            case 'recipe':
                return data.map(function(_ref2, index) {
                    var authorName = _ref2.authorName, images = _ref2.images, yields = _ref2.yields, category = _ref2.category, calories = _ref2.calories, aggregateRating = _ref2.aggregateRating, video = _ref2.video, ingredients = _ref2.ingredients, instructions = _ref2.instructions, cuisine = _ref2.cuisine, rest = _objectWithoutPropertiesLoose(_ref2, _excluded2$1);
                    return {
                        '@type': 'ListItem',
                        position: "" + (index + 1),
                        item: _extends({
                            '@context': 'https://schema.org',
                            '@type': 'Recipe'
                        }, rest, {
                            author: setAuthor(authorName),
                            image: images,
                            recipeYield: yields,
                            recipeCategory: category,
                            recipeCuisine: cuisine,
                            nutrition: setNutrition(calories),
                            aggregateRating: setAggregateRating(aggregateRating),
                            video: setVideo(video),
                            recipeIngredient: ingredients,
                            recipeInstructions: instructions.map(setInstruction)
                        })
                    };
                });
            case 'custom':
                return data.map(function(item, index) {
                    var _item$position;
                    return {
                        '@type': 'ListItem',
                        position: (_item$position = item.position) != null ? _item$position : index + 1,
                        item: {
                            '@type': item.type,
                            name: item.name
                        }
                    };
                });
        }
    }
    var jsonLdData = _extends({
        '@type': 'ItemList'
    }, rest, {
        itemListElement: generateList(data, ofType)
    }, rest);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, jsonLdData, {
        scriptKey: "Carousel"
    }));
}
var _excluded$u = [
    "type",
    "keyOverride",
    "url",
    "title",
    "images",
    "section",
    "dateCreated",
    "datePublished",
    "dateModified",
    "authorName",
    "authorType",
    "publisherName",
    "publisherLogo",
    "body",
    "isAccessibleForFree"
];
function NewsArticleJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'NewsArticle' : _ref$type, keyOverride = _ref.keyOverride, url = _ref.url, title = _ref.title, images = _ref.images, section = _ref.section, dateCreated = _ref.dateCreated, datePublished = _ref.datePublished, dateModified = _ref.dateModified, authorName = _ref.authorName, publisherName = _ref.publisherName, publisherLogo = _ref.publisherLogo, body = _ref.body, isAccessibleForFree = _ref.isAccessibleForFree, rest = _objectWithoutPropertiesLoose(_ref, _excluded$u);
    var data = _extends({}, rest, {
        mainEntityOfPage: {
            '@type': 'WebPage',
            '@id': url
        },
        headline: title,
        image: images,
        articleSection: section,
        dateCreated: dateCreated || datePublished,
        datePublished: datePublished,
        dateModified: dateModified || datePublished,
        author: setAuthor(authorName),
        publisher: setPublisher(publisherName, publisherLogo),
        articleBody: body,
        isAccessibleForFree: isAccessibleForFree
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "NewsArticle"
    }));
}
var _excluded$t = [
    "type",
    "keyOverride",
    "baseSalary",
    "hiringOrganization",
    "applicantLocationRequirements",
    "experienceRequirements",
    "jobLocation"
];
function JobPostingJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'JobPosting' : _ref$type, keyOverride = _ref.keyOverride, baseSalary = _ref.baseSalary, hiringOrganization = _ref.hiringOrganization, applicantLocationRequirements = _ref.applicantLocationRequirements, experienceRequirements = _ref.experienceRequirements, jobLocation = _ref.jobLocation, rest = _objectWithoutPropertiesLoose(_ref, _excluded$t);
    function setBaseSalary(baseSalary) {
        if (baseSalary) {
            return {
                '@type': 'MonetaryAmount',
                currency: baseSalary.currency,
                value: _extends({
                    '@type': 'QuantitativeValue',
                    unitText: baseSalary.unitText
                }, Array.isArray(baseSalary.value) ? {
                    minValue: baseSalary.value[0],
                    maxValue: baseSalary.value[1]
                } : {
                    value: baseSalary.value
                })
            };
        }
        return undefined;
    }
    function setHiringOrganization(org) {
        if (org === 'confidential') {
            return 'confidential';
        }
        return {
            '@type': 'Organization',
            name: org.name,
            sameAs: org.sameAs,
            logo: org.logo
        };
    }
    function setJobLocation(location) {
        if (location) {
            return {
                '@type': 'Place',
                address: {
                    '@type': 'PostalAddress',
                    addressCountry: location.addressCountry,
                    addressLocality: location.addressLocality,
                    addressRegion: location.addressRegion,
                    postalCode: location.postalCode,
                    streetAddress: location.streetAddress
                }
            };
        }
        return undefined;
    }
    function setApplicantLocationRequirements(requirements) {
        if (requirements) {
            return {
                '@type': 'Country',
                name: requirements
            };
        }
        return undefined;
    }
    function setOccupationalExperienceRequirements(requirements) {
        if (requirements) {
            return {
                '@type': requirements['@type'] ? requirements['@type'] : 'OccupationalExperienceRequirements',
                monthsOfExperience: requirements.minimumMonthsOfExperience
            };
        }
        return undefined;
    }
    function setEducationalOccupationalCredential(requirements) {
        if (requirements) {
            return {
                '@type': requirements['@type'] ? requirements['@type'] : 'EducationalOccupationalCredential',
                credentialCategory: requirements.credentialCategory
            };
        }
        return undefined;
    }
    var data = _extends({}, rest, {
        baseSalary: setBaseSalary(baseSalary),
        hiringOrganization: setHiringOrganization(hiringOrganization),
        jobLocation: setJobLocation(jobLocation),
        applicantLocationRequirements: setApplicantLocationRequirements(applicantLocationRequirements),
        experienceRequirements: setOccupationalExperienceRequirements(experienceRequirements == null ? void 0 : experienceRequirements.occupational),
        educationRequirements: setEducationalOccupationalCredential(experienceRequirements == null ? void 0 : experienceRequirements.educational),
        experienceInPlaceOfEducation: experienceRequirements == null ? void 0 : experienceRequirements.experienceInPlaceOfEducation
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "JobPosting"
    }));
}
function setAddress(address) {
    if (!address) return undefined;
    if (!Array.isArray(address)) return toPostalAddress(address);
    // If array of one address, replace with single address
    if (address.length === 1) return toPostalAddress(address[0]);
    // If array, return mapped array of PostalAddresses
    return address.map(toPostalAddress);
}
function toPostalAddress(address) {
    if (typeof address === 'string') return address;
    return _extends({
        '@type': 'PostalAddress'
    }, address);
}
function setGeo(geo) {
    if (geo) {
        return _extends({}, geo, {
            '@type': 'GeoCoordinates'
        });
    }
    return undefined;
}
function setAction(action) {
    if (action) {
        return {
            '@type': action.actionType,
            name: action.actionName,
            target: action.target
        };
    }
    return undefined;
}
function setGeoCircle(geoCircle) {
    if (geoCircle) {
        return {
            '@type': 'GeoCircle',
            geoMidpoint: {
                '@type': 'GeoCoordinates',
                latitude: geoCircle.geoMidpoint.latitude,
                longitude: geoCircle.geoMidpoint.longitude
            },
            geoRadius: geoCircle.geoRadius
        };
    }
    return undefined;
}
function setOffer(offer) {
    function setPriceSpecification(priceSpecification) {
        if (priceSpecification) {
            return {
                '@type': priceSpecification.type,
                priceCurrency: priceSpecification.priceCurrency,
                price: priceSpecification.price
            };
        }
        return undefined;
    }
    function setItemOffered(itemOffered) {
        if (itemOffered) {
            return _extends({}, itemOffered, {
                '@type': 'Service'
            });
        }
        return undefined;
    }
    if (offer) {
        return _extends({}, offer, {
            '@type': 'Offer',
            priceSpecification: setPriceSpecification(offer.priceSpecification),
            itemOffered: setItemOffered(offer.itemOffered)
        });
    }
    return undefined;
}
function setOpeningHours(openingHours) {
    if (openingHours) {
        return _extends({}, openingHours, {
            '@type': 'OpeningHoursSpecification'
        });
    }
    return undefined;
}
var _excluded$s = [
    "type",
    "keyOverride",
    "address",
    "geo",
    "rating",
    "review",
    "action",
    "areaServed",
    "makesOffer",
    "openingHours",
    "images"
];
function LocalBusinessJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'LocalBusiness' : _ref$type, keyOverride = _ref.keyOverride, address = _ref.address, geo = _ref.geo, rating = _ref.rating, review = _ref.review, action = _ref.action, areaServed = _ref.areaServed, makesOffer = _ref.makesOffer, openingHours = _ref.openingHours, images = _ref.images, rest = _objectWithoutPropertiesLoose(_ref, _excluded$s);
    var data = _extends({}, rest, {
        image: images,
        address: setAddress(address),
        geo: setGeo(geo),
        aggregateRating: setAggregateRating(rating),
        review: setReviews(review),
        potentialAction: setAction(action),
        areaServed: areaServed && areaServed.map(setGeoCircle),
        makesOffer: makesOffer == null ? void 0 : makesOffer.map(setOffer),
        openingHoursSpecification: Array.isArray(openingHours) ? openingHours.map(setOpeningHours) : setOpeningHours(openingHours)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "LocalBusiness"
    }));
}
var _excluded$r = [
    "type",
    "keyOverride",
    "mainEntity"
], _excluded2 = [
    "upvoteCount"
];
function QAPageJsonLd(_ref) {
    var _mainEntity$acceptedA;
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'QAPage' : _ref$type, keyOverride = _ref.keyOverride, mainEntity = _ref.mainEntity, rest = _objectWithoutPropertiesLoose(_ref, _excluded$r);
    var data = _extends({}, rest, {
        mainEntity: _extends({}, mainEntity, {
            '@type': 'Question',
            author: setAuthor(mainEntity.author)
        }, mainEntity.acceptedAnswer && {
            acceptedAnswer: _extends({}, mainEntity.acceptedAnswer, {
                '@type': 'Answer',
                author: setAuthor((_mainEntity$acceptedA = mainEntity.acceptedAnswer) == null ? void 0 : _mainEntity$acceptedA.author)
            })
        }, mainEntity.suggestedAnswer && {
            suggestedAnswer: mainEntity.suggestedAnswer.map(function(_ref2) {
                var upvoteCount = _ref2.upvoteCount, rest = _objectWithoutPropertiesLoose(_ref2, _excluded2);
                return _extends({}, rest, {
                    '@type': 'Answer',
                    upvoteCount: upvoteCount || 0,
                    author: setAuthor(rest.author)
                });
            })
        })
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "QAPage"
    }));
}
function setItemListElements(items) {
    if (items && items.length) {
        return items.map(function(item) {
            return {
                '@type': 'ListItem',
                position: item.position,
                item: item.item,
                name: item.name
            };
        });
    }
    return undefined;
}
var _excluded$q = [
    "type",
    "keyOverride",
    "breadcrumb"
];
function ProfilePageJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'ProfilePage' : _ref$type, keyOverride = _ref.keyOverride, breadcrumb = _ref.breadcrumb, rest = _objectWithoutPropertiesLoose(_ref, _excluded$q);
    var data = _extends({}, rest, {
        breadcrumb: Array.isArray(breadcrumb) ? {
            '@type': 'BreadcrumbList',
            itemListElement: setItemListElements(breadcrumb)
        } : breadcrumb
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "ProfilePage"
    }));
}
var _excluded$p = [
    "type",
    "keyOverride",
    "potentialActions"
];
function SiteLinksSearchBoxJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'WebSite' : _ref$type, keyOverride = _ref.keyOverride, potentialActions = _ref.potentialActions, rest = _objectWithoutPropertiesLoose(_ref, _excluded$p);
    function setPotentialAction(action) {
        if (action) {
            var target = action.target, queryInput = action.queryInput;
            return {
                '@type': 'SearchAction',
                target: target + "={" + queryInput + "}",
                'query-input': "required name=" + queryInput
            };
        }
        return undefined;
    }
    var data = _extends({}, rest, {
        potentialAction: potentialActions.map(setPotentialAction)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "jsonld-siteLinksSearchBox"
    }));
}
var _excluded$o = [
    "type",
    "keyOverride",
    "authorName",
    "images",
    "yields",
    "category",
    "cuisine",
    "calories",
    "aggregateRating",
    "video",
    "ingredients",
    "instructions"
];
function RecipeJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Recipe' : _ref$type, keyOverride = _ref.keyOverride, authorName = _ref.authorName, images = _ref.images, yields = _ref.yields, category = _ref.category, cuisine = _ref.cuisine, calories = _ref.calories, aggregateRating = _ref.aggregateRating, video = _ref.video, ingredients = _ref.ingredients, instructions = _ref.instructions, rest = _objectWithoutPropertiesLoose(_ref, _excluded$o);
    var data = _extends({}, rest, {
        author: setAuthor(authorName),
        image: images,
        recipeYield: yields,
        recipeCategory: category,
        recipeCuisine: cuisine,
        nutrition: setNutrition(calories),
        aggregateRating: setAggregateRating(aggregateRating),
        video: setVideo(video),
        recipeIngredient: ingredients,
        recipeInstructions: instructions ? instructions.map(setInstruction) : undefined
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "recipe"
    }));
}
function setLocation(location) {
    if (!location) {
        return undefined;
    }
    if (typeof location === 'string') {
        return location;
    }
    if ('url' in location) {
        return setVirtualLocation(location);
    } else {
        return setPlace(location);
    }
}
function setVirtualLocation(location) {
    return _extends({}, location, {
        '@type': 'VirtualLocation'
    });
}
function setPlace(location) {
    return _extends({}, location, {
        address: setAddress(location.address),
        '@type': 'Place'
    });
}
var _excluded$n = [
    "type"
];
function setPerformer(performer) {
    if (performer) {
        var type = performer.type, restPerformer = _objectWithoutPropertiesLoose(performer, _excluded$n);
        return _extends({}, restPerformer, {
            '@type': type || 'PerformingGroup'
        });
    }
    return undefined;
}
var _excluded$m = [
    "seller"
];
function setOffers(offers) {
    function mapOffer(_ref) {
        var seller = _ref.seller, rest = _objectWithoutPropertiesLoose(_ref, _excluded$m);
        return _extends({}, rest, {
            '@type': 'Offer'
        }, seller && {
            seller: {
                '@type': 'Organization',
                name: seller.name
            }
        });
    }
    if (Array.isArray(offers)) {
        return offers.map(mapOffer);
    } else if (offers) {
        return mapOffer(offers);
    }
    return undefined;
}
function setAggregateOffer(aggregateOffer) {
    if (aggregateOffer) {
        return {
            '@type': 'AggregateOffer',
            priceCurrency: aggregateOffer.priceCurrency,
            highPrice: aggregateOffer.highPrice,
            lowPrice: aggregateOffer.lowPrice,
            offerCount: aggregateOffer.offerCount,
            offers: setOffers(aggregateOffer.offers)
        };
    }
    return undefined;
}
var _excluded$l = [
    "type"
];
function setOrganizer(organizer) {
    if (organizer) {
        var type = organizer.type, restOrganizer = _objectWithoutPropertiesLoose(organizer, _excluded$l);
        return _extends({}, restOrganizer, {
            '@type': type || 'Person'
        });
    }
    return undefined;
}
var _excluded$k = [
    "type",
    "keyOverride",
    "location",
    "images",
    "offers",
    "aggregateOffer",
    "performers",
    "organizer",
    "eventStatus",
    "eventAttendanceMode"
];
function EventJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Event' : _ref$type, keyOverride = _ref.keyOverride, location = _ref.location, images = _ref.images, offers = _ref.offers, aggregateOffer = _ref.aggregateOffer, performers = _ref.performers, organizer = _ref.organizer, eventStatus = _ref.eventStatus, eventAttendanceMode = _ref.eventAttendanceMode, rest = _objectWithoutPropertiesLoose(_ref, _excluded$k);
    var data = _extends({}, rest, {
        location: setLocation(location),
        image: images,
        offers: offers ? setOffers(offers) : setAggregateOffer(aggregateOffer),
        performer: Array.isArray(performers) ? performers.map(setPerformer) : setPerformer(performers),
        organizer: Array.isArray(organizer) ? organizer.map(setOrganizer) : setOrganizer(organizer),
        eventStatus: eventStatus ? "https://schema.org/" + eventStatus : undefined,
        eventAttendanceMode: eventAttendanceMode ? "https://schema.org/" + eventAttendanceMode : undefined
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "Event"
    }));
}
function setContactPoint(contactPoint) {
    if (contactPoint) {
        return _extends({}, contactPoint, {
            '@type': 'ContactPoint'
        });
    }
    return undefined;
}
var _excluded$j = [
    "type",
    "keyOverride",
    "contactPoint"
];
function CorporateContactJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Organization' : _ref$type, keyOverride = _ref.keyOverride, contactPoint = _ref.contactPoint, rest = _objectWithoutPropertiesLoose(_ref, _excluded$j);
    var data = _extends({}, rest, {
        contactPoint: contactPoint.map(setContactPoint)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "CorporateContact"
    }));
}
function setCreativeWork(creativeWork) {
    if (creativeWork) {
        return _extends({}, creativeWork, {
            '@type': 'CreativeWork'
        });
    }
    return undefined;
}
var _excluded$i = [
    "type",
    "keyOverride",
    "hasPart"
];
function CollectionPageJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'CollectionPage' : _ref$type, keyOverride = _ref.keyOverride, hasPart = _ref.hasPart, rest = _objectWithoutPropertiesLoose(_ref, _excluded$i);
    var data = _extends({}, rest, {
        hasPart: hasPart.map(setCreativeWork)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "CollectionPage"
    }));
}
function setManufacturer(manufacturer) {
    if (manufacturer && (manufacturer.manufacturerName || manufacturer.manufacturerLogo)) {
        return {
            '@type': 'Organization',
            name: manufacturer.manufacturerName,
            logo: setImage(manufacturer.manufacturerLogo)
        };
    }
    return undefined;
}
function setBrand(brand) {
    if (brand) {
        return {
            '@type': 'Brand',
            name: brand
        };
    }
    return undefined;
}
var _excluded$h = [
    "type",
    "keyOverride",
    "images",
    "brand",
    "reviews",
    "aggregateRating",
    "manufacturerLogo",
    "manufacturerName",
    "offers",
    "aggregateOffer",
    "productName"
];
function ProductJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Product' : _ref$type, keyOverride = _ref.keyOverride, images = _ref.images, brand = _ref.brand, reviews = _ref.reviews, aggregateRating = _ref.aggregateRating, manufacturerLogo = _ref.manufacturerLogo, manufacturerName = _ref.manufacturerName, offers = _ref.offers, aggregateOffer = _ref.aggregateOffer, productName = _ref.productName, rest = _objectWithoutPropertiesLoose(_ref, _excluded$h);
    var data = _extends({}, rest, {
        image: images,
        brand: setBrand(brand),
        review: setReviews(reviews),
        aggregateRating: setAggregateRating(aggregateRating),
        manufacturer: setManufacturer({
            manufacturerLogo: manufacturerLogo,
            manufacturerName: manufacturerName
        }),
        offers: offers ? setOffers(offers) : setAggregateOffer(aggregateOffer),
        name: productName
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "Product"
    }));
}
var _excluded$g = [
    "type",
    "keyOverride",
    "priceCurrency",
    "price",
    "aggregateRating",
    "review",
    "keywords"
];
function SoftwareAppJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'SoftwareApplication' : _ref$type, keyOverride = _ref.keyOverride, priceCurrency = _ref.priceCurrency, price = _ref.price, aggregateRating = _ref.aggregateRating, review = _ref.review, keywords = _ref.keywords, rest = _objectWithoutPropertiesLoose(_ref, _excluded$g);
    var data = _extends({}, rest, {
        offers: {
            '@type': 'Offer',
            price: price,
            priceCurrency: priceCurrency
        },
        aggregateRating: setAggregateRating(aggregateRating),
        review: setReviews(review),
        keywords: keywords
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "SoftwareApp"
    }));
}
var _excluded$f = [
    "type",
    "keyOverride"
];
function VideoJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Video' : _ref$type, keyOverride = _ref.keyOverride, rest = _objectWithoutPropertiesLoose(_ref, _excluded$f);
    var data = setVideo(rest, true);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "Video"
    }));
}
function setProducer(producer) {
    if (producer) {
        return {
            '@type': 'Organization',
            sameAs: producer.url,
            name: producer.name
        };
    }
    return undefined;
}
function setProvider(provider) {
    if (provider) {
        return {
            '@type': provider.type || 'Organization',
            name: provider.name,
            sameAs: provider.url
        };
    }
    return undefined;
}
var _excluded$e = [
    "type",
    "keyOverride",
    "aggregateRating",
    "trailer",
    "reviews",
    "image",
    "authorName",
    "provider",
    "producerName",
    "producerUrl",
    "offers",
    "operatingSystemName",
    "platformName",
    "translatorName",
    "languageName",
    "genreName",
    "publisherName"
];
function VideoGameJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'VideoGame' : _ref$type, keyOverride = _ref.keyOverride, aggregateRating = _ref.aggregateRating, trailer = _ref.trailer, reviews = _ref.reviews, image = _ref.image, authorName = _ref.authorName, provider = _ref.provider, producerName = _ref.producerName, producerUrl = _ref.producerUrl, offers = _ref.offers, operatingSystemName = _ref.operatingSystemName, platformName = _ref.platformName, translatorName = _ref.translatorName, languageName = _ref.languageName, genreName = _ref.genreName, publisherName = _ref.publisherName, rest = _objectWithoutPropertiesLoose(_ref, _excluded$e);
    var data = _extends({}, rest, {
        aggregateRating: setAggregateRating(aggregateRating),
        trailer: setVideo(trailer),
        review: setReviews(reviews),
        image: setImage(image),
        author: setAuthor(authorName),
        provider: setProvider(provider),
        producer: setProducer({
            name: producerName,
            url: producerUrl
        }),
        offers: setOffers(offers),
        operatingSystem: operatingSystemName,
        gamePlatform: platformName,
        translator: translatorName,
        inLanguage: languageName,
        genre: genreName,
        publisher: publisherName
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "VideoGame"
    }));
}
function setContactPoints(contactPoint) {
    if (contactPoint && contactPoint.length) {
        return contactPoint.map(function(contactPoint) {
            return _extends({
                '@type': 'ContactPoint'
            }, contactPoint);
        });
    }
    return undefined;
}
var _excluded$d = [
    "type",
    "keyOverride",
    "address",
    "contactPoints",
    "contactPoint"
];
function OrganizationJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Organization' : _ref$type, keyOverride = _ref.keyOverride, address = _ref.address, contactPoints = _ref.contactPoints, contactPoint = _ref.contactPoint, rest = _objectWithoutPropertiesLoose(_ref, _excluded$d);
    var data = _extends({}, rest, {
        address: setAddress(address),
        contactPoint: setContactPoints(contactPoint || contactPoints)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "organization"
    }));
}
function setQuestions(questions) {
    if (questions && questions.length) {
        return questions.map(function(question) {
            return {
                '@type': 'Question',
                name: question.questionName,
                acceptedAnswer: {
                    '@type': 'Answer',
                    text: question.acceptedAnswerText
                }
            };
        });
    }
    return undefined;
}
var _excluded$c = [
    "type",
    "keyOverride",
    "mainEntity"
];
function FAQPageJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'FAQPage' : _ref$type, keyOverride = _ref.keyOverride, mainEntity = _ref.mainEntity, rest = _objectWithoutPropertiesLoose(_ref, _excluded$c);
    var data = _extends({}, rest, {
        mainEntity: setQuestions(mainEntity)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "faq-page"
    }));
}
var _excluded$b = [
    "type",
    "keyOverride"
];
function LogoJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Organization' : _ref$type, keyOverride = _ref.keyOverride, rest = _objectWithoutPropertiesLoose(_ref, _excluded$b);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, rest, {
        scriptKey: "Logo"
    }));
}
var _excluded$a = [
    "type",
    "keyOverride"
];
function DatasetJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Dataset' : _ref$type, keyOverride = _ref.keyOverride, rest = _objectWithoutPropertiesLoose(_ref, _excluded$a);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, rest, {
        scriptKey: "dataset"
    }));
}
var _excluded$9 = [
    "type",
    "keyOverride",
    "courseName",
    "provider"
];
function CourseJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Course' : _ref$type, keyOverride = _ref.keyOverride, courseName = _ref.courseName, provider = _ref.provider, rest = _objectWithoutPropertiesLoose(_ref, _excluded$9);
    var data = _extends({
        name: courseName
    }, rest, {
        provider: setProvider(provider)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "course"
    }));
}
var _excluded$8 = [
    "type",
    "keyOverride",
    "itemListElements"
];
function BreadCrumbJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'BreadcrumbList' : _ref$type, keyOverride = _ref.keyOverride, itemListElements = _ref.itemListElements, rest = _objectWithoutPropertiesLoose(_ref, _excluded$8);
    var data = _extends({}, rest, {
        itemListElement: setItemListElements(itemListElements)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "breadcrumb"
    }));
}
var _excluded$7 = [
    "type",
    "id",
    "keyOverride",
    "aggregateRating"
];
function BrandJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Brand' : _ref$type, id = _ref.id, keyOverride = _ref.keyOverride, aggregateRating = _ref.aggregateRating, rest = _objectWithoutPropertiesLoose(_ref, _excluded$7);
    var data = _extends({
        aggregateRating: setAggregateRating(aggregateRating),
        '@id': id
    }, rest);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "brand"
    }));
}
var _excluded$6 = [
    "type",
    "keyOverride",
    "url",
    "title",
    "images",
    "datePublished",
    "dateModified",
    "authorName",
    "publisherName",
    "publisherLogo",
    "description",
    "isAccessibleForFree"
];
function ArticleJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'Article' : _ref$type, keyOverride = _ref.keyOverride, url = _ref.url, title = _ref.title, images = _ref.images, datePublished = _ref.datePublished, dateModified = _ref.dateModified, authorName = _ref.authorName, _ref$publisherName = _ref.publisherName, publisherName = _ref$publisherName === void 0 ? undefined : _ref$publisherName, _ref$publisherLogo = _ref.publisherLogo, publisherLogo = _ref$publisherLogo === void 0 ? undefined : _ref$publisherLogo, description = _ref.description, isAccessibleForFree = _ref.isAccessibleForFree, rest = _objectWithoutPropertiesLoose(_ref, _excluded$6);
    var data = _extends({
        datePublished: datePublished,
        description: description,
        mainEntityOfPage: {
            '@type': 'WebPage',
            '@id': url
        },
        headline: title,
        image: images,
        dateModified: dateModified || datePublished,
        author: setAuthor(authorName),
        publisher: setPublisher(publisherName, publisherLogo),
        isAccessibleForFree: isAccessibleForFree
    }, rest);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "article"
    }));
}
function setReviewedBy(reviewedBy) {
    if (reviewedBy) {
        return _extends({
            '@type': (reviewedBy == null ? void 0 : reviewedBy.type) || 'Organization'
        }, reviewedBy);
    }
    return undefined;
}
var _excluded$5 = [
    "keyOverride",
    "reviewedBy"
];
function WebPageJsonLd(_ref) {
    var keyOverride = _ref.keyOverride, reviewedBy = _ref.reviewedBy, rest = _objectWithoutPropertiesLoose(_ref, _excluded$5);
    var data = _extends({}, rest, {
        reviewedBy: setReviewedBy(reviewedBy)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        keyOverride: keyOverride
    }, data, {
        type: "WebPage",
        scriptKey: "WebPage"
    }));
}
var _excluded$4 = [
    "type",
    "keyOverride"
];
function SocialProfileJsonLd(_ref) {
    var type = _ref.type, keyOverride = _ref.keyOverride, rest = _objectWithoutPropertiesLoose(_ref, _excluded$4);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, rest, {
        scriptKey: "social"
    }));
}
function setCost(cost) {
    if (cost) {
        return _extends({}, cost, {
            '@type': 'MonetaryAmount'
        });
    }
    return undefined;
}
function setSupply(supply) {
    if (supply) {
        return supply.map(function(supplyItem) {
            return {
                '@type': 'HowToSupply',
                name: supplyItem
            };
        });
    }
    return undefined;
}
function setTool(tool) {
    if (tool) {
        return tool.map(function(toolItem) {
            return {
                '@type': 'HowToTool',
                name: toolItem
            };
        });
    }
    return undefined;
}
function setStep(step) {
    if (step) {
        return step.map(function(stepElement) {
            var itemListElement = stepElement.itemListElement, image = stepElement.image;
            var currentListElements = itemListElement == null ? void 0 : itemListElement.map(function(_ref) {
                var type = _ref.type, text = _ref.text;
                return {
                    '@type': type,
                    text: text
                };
            });
            return _extends({}, stepElement, {
                '@type': 'HowToStep',
                itemListElement: currentListElements,
                image: setImage(image)
            });
        });
    }
    return undefined;
}
var _excluded$3 = [
    "type",
    "keyOverride",
    "image",
    "estimatedCost",
    "supply",
    "tool",
    "step"
];
function howToJsonLd(_ref) {
    var _ref$type = _ref.type, type = _ref$type === void 0 ? 'HowTo' : _ref$type, keyOverride = _ref.keyOverride, image = _ref.image, estimatedCost = _ref.estimatedCost, supply = _ref.supply, tool = _ref.tool, step = _ref.step, rest = _objectWithoutPropertiesLoose(_ref, _excluded$3);
    var data = _extends({}, rest, {
        image: setImage(image),
        estimatedCost: setCost(estimatedCost),
        supply: setSupply(supply),
        tool: setTool(tool),
        step: setStep(step)
    });
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "howTo"
    }));
}
var _excluded$2 = [
    "keyOverride",
    "images"
];
function ImageJsonLd(_ref) {
    var keyOverride = _ref.keyOverride, images = _ref.images, rest = _objectWithoutPropertiesLoose(_ref, _excluded$2);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({}, rest, {
        type: "ImageObject",
        keyOverride: keyOverride,
        dataArray: images,
        scriptKey: "image"
    }));
}
function setAmenityFeature(amenityFeature) {
    if (!amenityFeature) return undefined;
    if (!Array.isArray(amenityFeature)) {
        return decorateAmenityFeature(amenityFeature);
    }
    if (amenityFeature.length === 1) {
        return decorateAmenityFeature(amenityFeature[0]);
    }
    return amenityFeature.map(decorateAmenityFeature);
}
function decorateAmenityFeature(amenity) {
    return _extends({
        '@type': 'LocationFeatureSpecification'
    }, amenity);
}
var _excluded$1 = [
    "address",
    "geo",
    "images",
    "keyOverride",
    "openingHours",
    "type",
    "amenityFeature",
    "rating"
];
function CampgroundJsonLd(_ref) {
    var address = _ref.address, geo = _ref.geo, images = _ref.images, keyOverride = _ref.keyOverride, openingHours = _ref.openingHours, _ref$type = _ref.type, type = _ref$type === void 0 ? 'Campground' : _ref$type, amenityFeature = _ref.amenityFeature, rating = _ref.rating, rest = _objectWithoutPropertiesLoose(_ref, _excluded$1);
    var data = _extends({
        image: images,
        openingHoursSpecification: Array.isArray(openingHours) ? openingHours.map(setOpeningHours) : setOpeningHours(openingHours),
        address: setAddress(address),
        geo: setGeo(geo),
        amenityFeature: setAmenityFeature(amenityFeature),
        aggregateRating: setAggregateRating(rating)
    }, rest);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "campground"
    }));
}
var _excluded = [
    "address",
    "geo",
    "images",
    "keyOverride",
    "openingHours",
    "type"
];
function ParkJsonLd(_ref) {
    var address = _ref.address, geo = _ref.geo, images = _ref.images, keyOverride = _ref.keyOverride, openingHours = _ref.openingHours, _ref$type = _ref.type, type = _ref$type === void 0 ? 'Park' : _ref$type, rest = _objectWithoutPropertiesLoose(_ref, _excluded);
    var data = _extends({
        image: images,
        openingHoursSpecification: Array.isArray(openingHours) ? openingHours.map(setOpeningHours) : setOpeningHours(openingHours),
        address: setAddress(address),
        geo: setGeo(geo)
    }, rest);
    return /*#__PURE__*/ __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$compiled$2f$react$2f$index$2e$js__$5b$app$2d$client$5d$__$28$ecmascript$29$__["default"].createElement(JsonLd, _extends({
        type: type,
        keyOverride: keyOverride
    }, data, {
        scriptKey: "park"
    }));
}
;
}}),
}]);

//# sourceMappingURL=_a6d9a7._.js.map